"""
demo_lacrosse_scoop.py — 独立、可拷贝的并行舀球 demo。

用法(在另一台已经装好 Isaac Lab 的电脑上，把整个 lacrosse_scoop_demo/ 文件夹
拷过去，不需要放进 IsaacLab 源码树，也不需要 skrl/isaaclab_tasks 里有这个任务):

    cd /path/to/IsaacLab
    ./isaaclab.sh -p /path/to/lacrosse_scoop_demo/demo_lacrosse_scoop.py --num_envs 16

    无头模式(没有显示器/先冒烟测试):
    ./isaaclab.sh -p /path/to/lacrosse_scoop_demo/demo_lacrosse_scoop.py --headless --num_envs 4 --max_steps 200

这个脚本只依赖 isaaclab 的核心包(sim / assets / scene / envs / sensors /
actuators / utils)，不依赖 skrl，也不依赖仓库里的 isaaclab_tasks.direct.lacrosse_scoop
——策略网络是手写的一个小 MLP，直接从训练好的 skrl checkpoint 里把权重和观测
归一化统计量抄过来做纯 PyTorch 推理。机器人 USD 资产和 checkpoint 都放在这个
文件夹旁边的 assets/ 和 checkpoints/ 里一起带走，所以整个文件夹拷到 U 盘、
拷到任意一台装好 Isaac Lab 的机器上都能跑。

它会打开 N 个并行环境(默认 4x4=16 个)，每个环境里机器人在球前方 0.8-1.0m
处随机出现，训练好的策略会尝试舀起球并保持住；一旦 episode 结束(成功/超时/
出界)环境会自动重置，循环演示，类似 Isaac Lab 自带的四足机器人并行 demo。
"""

from __future__ import annotations

import argparse
import math
import os
from collections.abc import Sequence

from isaaclab.app import AppLauncher

# ── CLI args ───────────────────────────────────────────────────────────────
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))

parser = argparse.ArgumentParser(description="Lacrosse scoop — parallel policy playback demo")
parser.add_argument("--num_envs", type=int, default=16, help="并行环境数量(建议 4/9/16/25 摆成方阵)")
parser.add_argument("--checkpoint", type=str,
                     default=os.path.join(_THIS_DIR, "checkpoints", "best_agent.pt"),
                     help="训练好的 skrl PPO checkpoint 路径")
parser.add_argument("--env_spacing", type=float, default=4.0, help="相邻环境间距(米)")
parser.add_argument("--max_steps", type=int, default=0,
                     help="演示多少个 policy step 后自动退出；0 = 一直运行直到手动关闭窗口")
AppLauncher.add_app_launcher_args(parser)
args, _ = parser.parse_known_args()

app_launcher = AppLauncher(args)
simulation_app = app_launcher.app

# ── imports that require the sim app to already be running ─────────────────
import torch
import torch.nn as nn

import isaaclab.sim as sim_utils
from isaaclab.actuators import ImplicitActuatorCfg
from isaaclab.assets import Articulation, ArticulationCfg, RigidObject, RigidObjectCfg
from isaaclab.envs import DirectRLEnv, DirectRLEnvCfg
from isaaclab.scene import InteractiveSceneCfg
from isaaclab.sensors import ContactSensor, ContactSensorCfg
from isaaclab.sim import SimulationCfg
from isaaclab.utils import configclass
from isaaclab.utils.math import sample_uniform

ROBOT_USD = os.path.join(_THIS_DIR, "assets", "robot_v14.usda")
BALL_RADIUS = 0.032

# FK constants (must match training exactly — see lacrosse_scoop_env.py)
_SHOULDER_Z = 0.15
_L_ARM = 0.30
_POCKET_CX = 0.323
_POCKET_CZ = 0.07


def _spawn_ground_plane_local(prim_path: str) -> None:
    """Minimal physics-only ground plane — no Nucleus/network asset needed."""
    from pxr import UsdGeom, UsdPhysics, UsdShade
    import omni.usd

    stage = omni.usd.get_context().get_stage()
    if stage.GetPrimAtPath(prim_path).IsValid():
        return
    stage.DefinePrim(prim_path, "Xform")
    plane = UsdGeom.Plane.Define(stage, f"{prim_path}/CollisionPlane")
    plane.CreateAxisAttr("Z")
    UsdPhysics.CollisionAPI.Apply(plane.GetPrim())
    mc = UsdPhysics.MeshCollisionAPI.Apply(plane.GetPrim())
    mc.CreateApproximationAttr().Set("none")
    mat_prim = stage.DefinePrim(f"{prim_path}/PhysicsMaterial", "Material")
    phys_mat = UsdPhysics.MaterialAPI.Apply(mat_prim)
    phys_mat.CreateStaticFrictionAttr(0.6)
    phys_mat.CreateDynamicFrictionAttr(0.5)
    phys_mat.CreateRestitutionAttr(0.0)
    UsdShade.MaterialBindingAPI.Apply(plane.GetPrim()).Bind(
        UsdShade.Material(mat_prim),
        bindingStrength=UsdShade.Tokens.strongerThanDescendants,
        materialPurpose="physics",
    )


# ── environment (inference-only trim of lacrosse_scoop_env.py) ─────────────

@configclass
class DemoEnvCfg(DirectRLEnvCfg):
    decimation: int = 20
    episode_length_s: float = 10.0
    action_space: int = 3
    observation_space: int = 11
    state_space: int = 0

    sim: SimulationCfg = SimulationCfg(dt=1.0 / 1200.0, render_interval=20)

    scene: InteractiveSceneCfg = InteractiveSceneCfg(
        num_envs=16, env_spacing=4.0, replicate_physics=True
    )

    robot_cfg: ArticulationCfg = ArticulationCfg(
        prim_path="/World/envs/env_.*/Robot",
        spawn=sim_utils.UsdFileCfg(
            usd_path=ROBOT_USD,
            activate_contact_sensors=True,
            rigid_props=sim_utils.RigidBodyPropertiesCfg(
                disable_gravity=False, max_depenetration_velocity=5.0,
            ),
            articulation_props=sim_utils.ArticulationRootPropertiesCfg(
                enabled_self_collisions=False,
                solver_position_iteration_count=8,
                solver_velocity_iteration_count=1,
            ),
        ),
        init_state=ArticulationCfg.InitialStateCfg(
            joint_pos={"ChassisSlideJoint": 0.0, "ShoulderJoint": 0.0, "ElbowJoint": 0.0},
        ),
        actuators={
            "chassis": ImplicitActuatorCfg(
                joint_names_expr=["ChassisSlideJoint"],
                stiffness=0.0, damping=1000.0,
                effort_limit_sim=500.0, velocity_limit_sim=3.0,
            ),
            "arm": ImplicitActuatorCfg(
                joint_names_expr=["ShoulderJoint", "ElbowJoint"],
                stiffness=0.0, damping=500.0,
                effort_limit_sim=200.0, velocity_limit_sim=4.0,
            ),
        },
    )

    ball_cfg: RigidObjectCfg = RigidObjectCfg(
        prim_path="/World/envs/env_.*/Ball",
        spawn=sim_utils.SphereCfg(
            radius=BALL_RADIUS,
            activate_contact_sensors=False,
            rigid_props=sim_utils.RigidBodyPropertiesCfg(),
            mass_props=sim_utils.MassPropertiesCfg(mass=0.145),
            collision_props=sim_utils.CollisionPropertiesCfg(),
            physics_material=sim_utils.RigidBodyMaterialCfg(
                static_friction=0.8, dynamic_friction=0.7, restitution=0.3
            ),
            visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.9, 0.5, 0.1)),
        ),
        init_state=RigidObjectCfg.InitialStateCfg(pos=(-0.9, 0.0, BALL_RADIUS)),
    )

    contact_cfg: ContactSensorCfg = ContactSensorCfg(
        prim_path="/World/envs/env_.*/Robot/EndEffector",
        filter_prim_paths_expr=["/World/envs/env_.*/Ball"],
        update_period=1.0 / 60.0,
        history_length=1,
    )

    # action scales — must match training
    vx_accel: float = 0.215   # curriculum value at the deployed checkpoint's training step (~60k)
    vx_max: float = 2.0
    vq_scale: float = 2.0

    # termination thresholds — must match training
    pocket_z_min: float = 0.05
    ball_z_max: float = 0.8
    ball_x_rel_min: float = -2.5
    ball_x_rel_max: float = 2.5

    # ball spawn range — must match training
    ball_x_min: float = -1.0
    ball_x_max: float = -0.8

    contact_force_threshold: float = 0.5
    success_hold_steps: int = 5
    vel_success: float = 0.50


class DemoEnv(DirectRLEnv):
    cfg: DemoEnvCfg

    def __init__(self, cfg: DemoEnvCfg, render_mode: str | None = None, **kwargs):
        super().__init__(cfg, render_mode, **kwargs)
        self._x_idx = self.robot.find_joints("ChassisSlideJoint")[0][0]
        self._q1_idx = self.robot.find_joints("ShoulderJoint")[0][0]
        self._q2_idx = self.robot.find_joints("ElbowJoint")[0][0]
        self._x_vel_target = torch.zeros(self.num_envs, device=self.device)
        self._success_hold = torch.zeros(self.num_envs, device=self.device, dtype=torch.long)

        # live stats for the demo banner
        self.total_episodes = 0
        self.total_successes = 0

    def _setup_scene(self):
        self.robot = Articulation(self.cfg.robot_cfg)
        self.ball = RigidObject(self.cfg.ball_cfg)
        self.contact = ContactSensor(self.cfg.contact_cfg)
        self.scene.articulations["robot"] = self.robot
        self.scene.rigid_objects["ball"] = self.ball
        self.scene.sensors["contact"] = self.contact
        _spawn_ground_plane_local("/World/ground")
        self.scene.clone_environments(copy_from_source=False)
        self.scene.filter_collisions(global_prim_paths=["/World/ground"])
        light_cfg = sim_utils.DomeLightCfg(intensity=2000.0, color=(0.75, 0.75, 0.75))
        light_cfg.func("/World/Light", light_cfg)

    def _pocket_pos_w(self):
        q = self.robot.data.joint_pos
        x, q1, q2 = q[:, self._x_idx], q[:, self._q1_idx], q[:, self._q2_idx]
        theta = q1 + q2
        ex = _L_ARM * torch.sin(q1)
        ez = _SHOULDER_Z + _L_ARM * torch.cos(q1)
        pocket_x = x + ex - _POCKET_CX * torch.cos(theta) - _POCKET_CZ * torch.sin(theta)
        pocket_z = ez + _POCKET_CX * torch.sin(theta) - _POCKET_CZ * torch.cos(theta)
        return pocket_x, pocket_z

    def _ee_ball_force(self):
        return self.contact.data.net_forces_w.norm(dim=-1).squeeze(-1)

    def _pre_physics_step(self, actions: torch.Tensor) -> None:
        a = actions.clamp(-1.0, 1.0)
        self._x_vel_target += a[:, 0] * self.cfg.vx_accel
        self._x_vel_target.clamp_(-self.cfg.vx_max, self.cfg.vx_max)
        self._q1_vel = a[:, 1] * self.cfg.vq_scale
        self._q2_vel = a[:, 2] * self.cfg.vq_scale

        ball_vel = self.ball.data.root_vel_w.clone()
        ball_vel[:, 1] = 0.0
        ball_vel[:, 3] = 0.0
        ball_vel[:, 5] = 0.0
        self.ball.write_root_velocity_to_sim(ball_vel)

    def _apply_action(self) -> None:
        vel_targets = torch.zeros(self.num_envs, self.robot.num_joints, device=self.device)
        vel_targets[:, self._x_idx] = self._x_vel_target
        vel_targets[:, self._q1_idx] = self._q1_vel
        vel_targets[:, self._q2_idx] = self._q2_vel
        self.robot.set_joint_velocity_target(vel_targets)

    def _get_observations(self) -> dict:
        q, qd = self.robot.data.joint_pos, self.robot.data.joint_vel
        ball_x, ball_z = self.ball.data.root_pos_w[:, 0], self.ball.data.root_pos_w[:, 2]
        ball_rot_y = self.ball.data.root_quat_w[:, 2]
        pocket_x, pocket_z = self._pocket_pos_w()
        dx, dz = ball_x - pocket_x, ball_z - pocket_z
        ball_vx, ball_vz = self.ball.data.root_vel_w[:, 0], self.ball.data.root_vel_w[:, 2]
        obs = torch.stack([
            q[:, self._x_idx], q[:, self._q1_idx], q[:, self._q2_idx],
            qd[:, self._x_idx], qd[:, self._q1_idx], qd[:, self._q2_idx],
            dx, dz, ball_rot_y, ball_vx, ball_vz,
        ], dim=-1)
        return {"policy": obs}

    def _get_rewards(self) -> torch.Tensor:
        # not used at inference time — keep the interface happy
        return torch.zeros(self.num_envs, device=self.device)

    def _get_dones(self):
        time_out = self.episode_length_buf >= self.max_episode_length - 1
        _, pocket_z = self._pocket_pos_w()
        head_ground = pocket_z < self.cfg.pocket_z_min
        env_ox = self.scene.env_origins[:, 0]
        ball_x_rel = self.ball.data.root_pos_w[:, 0] - env_ox
        ball_oob = (ball_x_rel < self.cfg.ball_x_rel_min) | (ball_x_rel > self.cfg.ball_x_rel_max)
        ball_high = self.ball.data.root_pos_w[:, 2] > self.cfg.ball_z_max

        ee_force = self._ee_ball_force()
        ball_z = self.ball.data.root_pos_w[:, 2]
        ball_speed = self.ball.data.root_vel_w[:, :3].norm(dim=-1)
        holding = (ee_force > self.cfg.contact_force_threshold) & (ball_z > BALL_RADIUS * 2.5)
        success_cond = holding & (ball_speed < self.cfg.vel_success)
        self._success_hold = torch.where(success_cond, self._success_hold + 1, torch.zeros_like(self._success_hold))
        success = self._success_hold >= self.cfg.success_hold_steps

        terminated = head_ground | ball_oob | ball_high | success
        truncated = time_out & ~terminated

        any_done = terminated | truncated
        if any_done.any():
            n_done = int(any_done.sum().item())
            n_success = int(success.sum().item())
            self.total_episodes += n_done
            self.total_successes += n_success
            if self.total_episodes and self.total_episodes % 20 < n_done:
                rate = 100.0 * self.total_successes / max(self.total_episodes, 1)
                print(f"[demo] episodes so far: {self.total_episodes}  "
                      f"successes: {self.total_successes}  (~{rate:.0f}%)")

        return terminated, truncated

    def _reset_idx(self, env_ids: Sequence[int] | None):
        if env_ids is None:
            env_ids = self.robot._ALL_INDICES
        super()._reset_idx(env_ids)
        n = len(env_ids)

        home_pos = torch.zeros(n, self.robot.num_joints, device=self.device)
        home_vel = torch.zeros_like(home_pos)
        self.robot.write_joint_state_to_sim(home_pos, home_vel, env_ids=env_ids)

        self._x_vel_target[env_ids] = 0.0
        self._success_hold[env_ids] = 0

        rand_x = sample_uniform(self.cfg.ball_x_min, self.cfg.ball_x_max, (n,), device=self.device)
        ball_state = self.ball.data.default_root_state[env_ids].clone()
        ball_state[:, 0] = self.scene.env_origins[env_ids, 0] + rand_x
        ball_state[:, 1] = self.scene.env_origins[env_ids, 1]
        ball_state[:, 2] = BALL_RADIUS
        ball_state[:, 7:13] = 0.0
        self.ball.write_root_state_to_sim(ball_state, env_ids=env_ids)


# ── minimal pure-PyTorch policy (no skrl dependency at inference time) ──────

class _PolicyNet(nn.Module):
    """Mirrors the trained skrl actor: Linear(11,256)-ELU-Linear(256,128)-ELU-Linear(128,3)."""

    def __init__(self, obs_dim: int = 11, act_dim: int = 3):
        super().__init__()
        self.fc1 = nn.Linear(obs_dim, 256)
        self.fc2 = nn.Linear(256, 128)
        self.out = nn.Linear(128, act_dim)
        self.act = nn.ELU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.act(self.fc1(x))
        x = self.act(self.fc2(x))
        return self.out(x)  # mean action (deterministic — no sampling at inference)


def load_policy(checkpoint_path: str, device: str):
    print(f"[demo] Loading checkpoint: {checkpoint_path}")
    ckpt = torch.load(checkpoint_path, map_location=device, weights_only=False)
    sd = ckpt["policy"]

    net = _PolicyNet().to(device)
    net.fc1.weight.data.copy_(sd["net_container.0.weight"])
    net.fc1.bias.data.copy_(sd["net_container.0.bias"])
    net.fc2.weight.data.copy_(sd["net_container.2.weight"])
    net.fc2.bias.data.copy_(sd["net_container.2.bias"])
    net.out.weight.data.copy_(sd["policy_layer.weight"])
    net.out.bias.data.copy_(sd["policy_layer.bias"])
    net.eval()

    pp = ckpt["observation_preprocessor"]
    obs_mean = pp["running_mean"].to(device).float()
    obs_var = pp["running_variance"].to(device).float()
    return net, obs_mean, obs_var


def normalize_obs(obs: torch.Tensor, mean: torch.Tensor, var: torch.Tensor,
                   eps: float = 1e-8, clip: float = 5.0) -> torch.Tensor:
    return torch.clamp((obs - mean) / (torch.sqrt(var) + eps), -clip, clip)


# ── run the demo ─────────────────────────────────────────────────────────

def main():
    device = "cuda:0" if torch.cuda.is_available() else "cpu"

    cfg = DemoEnvCfg()
    cfg.scene.num_envs = args.num_envs
    cfg.scene.env_spacing = args.env_spacing

    env = DemoEnv(cfg, render_mode="human" if not args.headless else None)
    policy, obs_mean, obs_var = load_policy(args.checkpoint, device)

    # frame the camera around the grid of environments
    grid = math.ceil(math.sqrt(args.num_envs))
    span = grid * args.env_spacing
    try:
        env.sim.set_camera_view(eye=(span * 0.6, -span * 0.6, span * 0.55), target=(0.0, 0.0, 0.0))
    except Exception:
        pass

    print(f"[demo] {args.num_envs} parallel envs on {device}. Ctrl+C to quit.")
    obs, _ = env.reset()
    step = 0
    while simulation_app.is_running():
        with torch.no_grad():
            obs_n = normalize_obs(obs["policy"], obs_mean, obs_var)
            action = policy(obs_n).clamp(-1.0, 1.0)
        obs, _, _, _, _ = env.step(action)

        step += 1
        if args.max_steps and step >= args.max_steps:
            break

    env.close()


if __name__ == "__main__":
    main()
    simulation_app.close()
