铲球 RL 策略 —— 便携并行 demo
================================

这个文件夹是完全独立的，不依赖仓库里的 isaaclab_tasks/lacrosse_scoop，也不
依赖 skrl。整个文件夹（约 5MB）可以直接拷到 U 盘，放到任意一台已经装好
Isaac Lab 的电脑上就能跑，用法和 Isaac Lab 自带的验证安装用的四足机器人
demo 完全一样：

    cd <目标机器上的 IsaacLab 目录>
    ./isaaclab.sh -p <U盘路径>/lacrosse_scoop_demo/demo_lacrosse_scoop.py --num_envs 16

会打开一个 GUI 窗口，摆成方阵的 N 个环境里，机器人各自尝试舀起面前的球，
一局结束（成功 / 超时 / 出界）自动重置，循环演示。终端里每 20 局左右会打印一次
累计成功率。

常用参数
--------
--num_envs N        并行环境数量，摆成 ceil(sqrt(N)) x ceil(sqrt(N)) 的方阵，
                     默认 16。显卡吃得消的话 25/36 效果更好看。
--headless           不开 GUI，先冒烟测试用（配合 --max_steps 用几秒钟测试能不能
                     正常跑起来，再上正式演示）：
                         ./isaaclab.sh -p demo_lacrosse_scoop.py --headless --num_envs 4 --max_steps 200
--checkpoint PATH    换一个策略 checkpoint（默认用文件夹自带的
                     checkpoints/best_agent.pt，也就是 dense_v16 训练里
                     skrl 认为最好的一版）。
--env_spacing M      环境间距（米），默认 4.0，环境数多的话可以调大一点防止
                     相邻方阵挡视线。

文件夹里有什么
--------------
demo_lacrosse_scoop.py   主脚本：环境定义 + 手写的纯 PyTorch 策略推理，
                         不需要目标机器上装 skrl。
assets/robot_v14.usda    机器人 USD 资产（自包含，无外部引用，不需要联网）。
checkpoints/best_agent.pt  训练好的策略权重（PPO, skrl 格式，脚本自己解析
                         里面的网络权重和观测归一化统计量，不调用 skrl API）。

这个策略是怎么训练出来的、reward 具体是什么，见仓库里的
docs/lacrosse_scoop_readme.md。

已知限制
--------
- 这是纯推理 demo，没有做过在异构 GPU / 无独显机器上的实测；理论上只要
  Isaac Sim 本身能跑，PhysX 仿真部分和训练时一致，不依赖具体显卡型号。
- 动作缩放里的 vx_accel=0.215 是照抄训练时 best_agent 对应 step(~60k)的
  curriculum 取值，不是自适应的——如果你换成别的 checkpoint（比如更早或更晚
  的 agent_XXXXX.pt），底盘的加速度手感可能和训练时略有出入，属预期行为。
